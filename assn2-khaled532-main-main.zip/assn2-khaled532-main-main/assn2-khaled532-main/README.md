[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/Ao9PJLSK)
# COIS 2430 Assignment #2

- [COIS 2430 Assignment #2](#cois-2430-assignment-2)
  - [Some General Requirements to Start](#some-general-requirements-to-start)
  - [Question One - More Page Components](#question-one---more-page-components)
    - [Part A - A Web Table](#part-a---a-web-table)
    - [Part B - A Navigation](#part-b---a-navigation)
    - [Part C - A Login Form](#part-c---a-login-form)
    - [HTML View with only Default Browser Styles](#html-view-with-only-default-browser-styles)
    - [HTML View After Reset (no default browser styles)](#html-view-after-reset-no-default-browser-styles)
    - [CSS Styled Page](#css-styled-page)
    - [CSS Styles Illustrating Some State Behaviour](#css-styles-illustrating-some-state-behaviour)
  - [Question Two - Combining Everything You've Learned](#question-two---combining-everything-youve-learned)
  - [Question Three - Scripting with JavaScript Core](#question-three---scripting-with-javascript-core)
    - [Part A - Leap Years](#part-a---leap-years)
    - [Part B - Pyramid Building](#part-b---pyramid-building)
    - [Part C - Title Case](#part-c---title-case)

## Some General Requirements to Start

For questions one & two, you are not allowed to use the following:

- No pixels!!!
- No nested CSS
- No libraries, themes or frameworks. The only exceptions would be an icon library like font-awesome and/or a syntax highlighting library.
- No JavaScript (except as necessary for the above allowed libraries)
- No inline or embedded CSS (it must all be in your external file)
- Only use CSS covered in Modules One - Six.

For all three questions your testing must:

- Be correctly included (and labelled) in the _testing.md_ file.
- Be both cross-browser and cross-platform (following the same rules provided for assignment #1).
- Questions one and two must include HTML validation results for each page, showing your HTML is valid.
- Testing for questions one and two, should also illustrate any "state" changes, like hover.
- Include proof of accessibility testing for question two (not just color contrast).
- For question three, your testing should follow what you learned in 1020, and test a reasonable number of cases to illustrate that your code works.
- **Make sure your testing file renders correctly and images load when viewed in your GitHub repository online**

Note: You are also expected to provide properly formatted well-documented code in all your code files. There are marks for the quality of both the code and documentation.

Along with code quality, documentation and testing, the rubric for this assignment also contains marks for "good git habits". **This means frequent, atomic commits with meaningful commit messages!**

## Question One - More Page Components

For this question, you're going to write the HTML and CSS to generate the a couple of different page components. All three parts MUST be completed on a single HTML page. Please read the following carefully:

- Add a level one heading with the assignment question and your name.
- Place each tasks in its own <section> with a level 2 heading. These sections should have IDs to make it easier write your styles specific to each part.
- You are expected to make the most semantic and accessible choices possible for all HTML elements. Extraneous markup should be kept to a minimum.
- You must start your styling with the CSS reset provided in this file to ensure all styles are your own.

Since you will lose significant marks if you don't use the reset correctly, I would suggest importing the reset at the top of your CSS first, and verify that all styling is gone before continuing on.


Since part of the point is to encourage your use of various selectors, for full marks, other than the above sections, and any form elements that need them for labels, you should only use classes and IDs for necessary semantics and with Font-Awesome icons. Over use of classes and IDs strictly for styling will affect your quality mark.

However, if you're unable to figure out how to select something without giving it a class/ID, give it one. There will be a deduction, but that's certainly better than a 0.

### Part A - A Web Table

Part A includes an HTML table. Information you need includes:

- Color Codes: #755c75, #51344d, #8c93a8, #d0c3d0,aa98aa, green, firebrick, white
- Font: Google Font (Poiret One)
- Icons: Font Awesome (fa-check, fa-times)

For a good mark, it's important that you make this table as accessible as possible by implementing the concepts covered in modules six. A proper accessible table structure will also make it easier to apply the styling outlined below.

### Part B - A Navigation

Part B is the navigation component of a page. Information you need includes:

- Color Codes:
  - Visiting links: #ff6666
  - Unvisited links: #ccff66
  - Hovered links: white
  - Search box: #2ec4b6
  - rebeccapurple
  - white
- Font: Google Font (Roboto)
- Icons: Font Awesome (fa-quidditch, fa-search)

This is a flexbox based navigation menu. Other then padding, all spacing/positioning should be controlled using flex properties.

The home link in the nav should point to your assignment file (to triggers visited styling).

In the "state" screenshot below, Home is visited, Services is hovered (the mouse doesn't show up in the screenshot) and Products is unvisited.

### Part C - A Login Form

This is the centered modal style login form in the pictures below.

Information you need to complete part C includes:

- Color Codes
  - Blue color: #4285f4
  - you can pick a color for the visited hyperlinks (should at least kind of match)
- Font: Google Font (Roboto)
- The all-caps is css styling (not capital letters in the HTML)
- The form should be laid out using either flexbox or grid

Note: There is styling on this form that requires some unnecessarily complex css selectors, without adding classes. In reality, there is one situation where adding a class would actually be better practice then the complex selector. However since part of this intellectual exercise is illustrating your grasp of selectors, you should still try to complete this part without adding classes or ids.

### HTML View with only Default Browser Styles

Note: This imgae is intended solely to provide you some guidance in what the HTML might be. Screenshots of your HTML are not required in your testing, only the finished product.

![](./q2-demoshots/browser-styles.png)

### HTML View After Reset (no default browser styles)

![](./q2-demoshots/after-reset.png)

### CSS Styled Page

![](./q2-demoshots/css-styles.png)

### CSS Styles Illustrating Some State Behaviour

![](./q2-demoshots/state-view.png)

## Question Two - Combining Everything You've Learned

Next, you are going to combine everything you've learned about HTML and CSS to make a static site portfolio piece.

The page should first introduce yourself. The content is up to you, but should include a variety of HTML elements, not just text.

This should be followed by an online (HTML-ified) version of your CV (Resume).

The following is a minimum list of requirements you should have across all your content:

- Both pages should start with a CSS reset (imported into your CSS, not included in your HTML)
- Semantic use of HTML5 sectioning elements for page structure
- A variety other semantic HTML elements
- Meaningful use of Grid, Flexbox and the Box Model as appropriate for different layout components
- A table
- An image
- Good use of CSS Custom Properties (variables)
- Non-trivial use of CSS animation
- Use of pseudeo elements
- An accessible colour palette
- Use of media queries

The focus of this course is development, not design. However, being able to replicate a provided design for the web is industry relevant experience. It’s not uncommon for a developer to be provided a .psd file designed by someone else, and be asked to reproduce it with HTML and CSS.

For your CV page, you must choose a design from: [https://dribbble.com/tags/resume](https://dribbble.com/tags/resume) and attempt to replicate it. _A link to the design you chose must be crediting the footer of your page(s)._

This question does include a complexity mark based on the design and content you choose.

Since you can't determine the semantic markup for content without meaning, failure to provide meaningful content will result in serious deductions. Pages full of lorem ipsum will receive a failing grade.

## Question Three - Scripting with JavaScript Core

Finally, your going to write several small javascript functions to practice with javascript core programming (basically just using javascript as a normal scripting language). For each section you can hardcode input values, and all output should go to console (we'll worry about the actual web page on Assignment 4). You can complete these all in one HTML file, or create one file for each part.

### Part A - Leap Years

Write a function that accepts a year, and works out whether if a given year is a leap year (returning true if it is a leap year and false if it isn't). A normal year has 365 days, leap years have 366, with an extra day in February.

This is how to work out whether if a particular year is a leap year:

A year is a leap year if it is evenly divisible by 4 ;

except if that year is also evenly divisible by 100 but not 400;

Call the function and with the result use a string template literal to print out a sentence including the year, and if it is a leap year or not.

### Part B - Pyramid Building

Write a function that accepts a number (the height of the pyramid), and creates an array of strings where each string represents a level in the pyramid. Each block in the pyramid is represented by the `@` character. The array should be returned from the function and printed to the console.

So for example a pyramid of `3` levels would look like:

```shell
[
  "  @  ",
  " @@@ ",
  "@@@@@"
]
```

and a pyramid with `5` levels would look like:

```shell
[
  "    @    ",
  "   @@@   ",
  "  @@@@@  ",
  " @@@@@@@ ",
  "@@@@@@@@@"
]
```

### Part C - Title Case

Write a function that accepts a string and return the string with the first letter of every word (and only the first letter) capitalized. Log the original string, and resulting string to the console.
