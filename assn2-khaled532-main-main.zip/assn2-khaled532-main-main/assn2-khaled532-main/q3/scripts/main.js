// Part A - Leap Year Function
function isLeapYear(year) {
    return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}

// Test Leap Year Function
const leapYearToTest = 2024; // Renamed from testYear to avoid conflicts
console.log(`${leapYearToTest} is a leap year: ${isLeapYear(leapYearToTest)}`);

// Part B - Pyramid Builder
function buildPyramid(height) {
    let pyramid = [];
    for (let i = 0; i < height; i++) {
        let spaces = " ".repeat(height - i - 1);
        let blocks = "@".repeat(2 * i + 1);
        pyramid.push(spaces + blocks + spaces);
    }
    return pyramid;
}

// Test Pyramid Function
const pyramidHeight = 5;
console.log(buildPyramid(pyramidHeight).join("\n"));

// Part C - Title Case Converter
function titleCase(str) {
    return str
        .split(" ")
        .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
        .join(" ");
}

// Test Title Case Function
const titleTestString = "hello world, this is a title case test"; // Renamed variable
console.log(`Original: ${titleTestString}`);
console.log(`Title Case: ${titleCase(titleTestString)}`);
